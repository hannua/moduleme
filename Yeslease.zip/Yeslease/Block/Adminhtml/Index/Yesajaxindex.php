<?php

namespace Conns\Yeslease\Block\Adminhtml\Index;

class Yesajaxindex extends \Magento\Framework\View\Element\Template
{

    public function getHelloWorldTxt()
    {
        return 'Ye lease!';
    }



}
