<?php

namespace Conns\Yeslease\Block\Adminhtml\Order\View\Tab;

class Info extends  \Magento\Sales\Block\Adminhtml\Order\View\Tab\Info{



}