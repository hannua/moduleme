<?php

namespace Conns\Yeslease\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Conns\Yeslease\Helper\Data as HelperData;
use Conns\Restservices\Helper\Restobj;
use Magento\Sales\Model\Order;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\Order\Email\Sender\InvoiceSender;

class Yesajax extends \Magento\Framework\App\Action\Action
{
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\App\Request\Http $request,
        HelperData $helperData,
        OrderRepositoryInterface $orderRepository,
        Restobj $restobj,
        \Magento\Sales\Model\Service\InvoiceService $invoiceService,
        InvoiceSender $invoiceSender
    )
    {
        $this->request = $request;
        $this->helperData = $helperData;
        $this->orderRepository = $orderRepository;
        $this->restobj = $restobj;
        $this->invoiceService = $invoiceService;
        $this->invoiceSender = $invoiceSender;
        return parent::__construct($context);
    }

    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();

        $orderId = $this->request->getParam('order_id');
        $order = $this->orderRepository->get($orderId);
        $leaseId = $order->getPayment()->getAdditionalInformation('lease_number');
        if (!empty($leaseId)) {
            $result = $this->helperData->getDelivconfirmStatus($leaseId);
            if ($result->errorCode == "Y") {
                return;
            }
            if (!$order->getId()) {
                throw new \Magento\Framework\Exception\LocalizedException(__('The order no longer exists.'));
            }
            if ((trim($result->Response->ApprovalStatus) == "Contracts Received" || trim($result->Response->ApprovalStatus) == "Funded")
                && $result->Response->OkayToDeliver == true
            ) {
                if ($result->Response->InvoiceCreated == true && !empty($result->Response->Invoice->InvoiceNumber)) {
                    $this->messageManager->addSuccess(__('Contracts are signed and system has generated the AS400 invoice. Please contact customer and schedule delivery.'));
                    $order->setConnsInvoiceId($result->Response->Invoice->InvoiceNumber);
                } else {
                    $response = $this->restobj->invoiceNewForSalesOrder($order);
                    if ($response && isset($response->status)
                        && $response->status == Restobj::STATUS_SUCCESS
                        && isset($response->Response)
                    ) {
                        $this->messageManager->addSuccess(__('Contracts are signed and system has generated the AS400 invoice. Please contact customer and schedule delivery.'));
                        try {
                            $order->setConnsInvoiceId($response->Response->connsInvoiceNumber);
                            $order->setConnsQuoteId($response->Response->connsQuoteNumber);
                            $order->setConnsCustomerId($response->Response->Billing->connsCustomerId);
							date_default_timezone_set("America/Chicago");
							$state 			= "approvedyesmoney";													 
							$orderStatus 	= "docusign_complete";
							$timeNow 		= date('Y-m-d H:i:s', strtotime("now"));
							$comment     	= "Order state changed at: " . $timeNow;
							$order->setState($state);
							$order->setStatus($orderStatus);
							$order->addStatusToHistory($orderStatus, $comment, false);
                            $order->save();
                            if (!$order->canInvoice()) {
                                throw new \Magento\Framework\Exception\LocalizedException(
                                    __('The order does not allow an invoice to be created.')
                                );
                            }
                            $invoice = $this->invoiceService->prepareInvoice($order);

                            if (!$invoice) {
                                throw new LocalizedException(__('We can\'t save the invoice right now.'));
                            }

                            if (!$invoice->getTotalQty()) {
                                throw new \Magento\Framework\Exception\LocalizedException(
                                    __('You can\'t create an invoice without products.')
                                );
                            }
                            $invoice->register();

                            $invoice->getOrder()->setCustomerNoteNotify(false);
                            $invoice->getOrder()->setIsInProcess(true);

                            $transactionSave = $this->_objectManager->create(
                                \Magento\Framework\DB\Transaction::class
                            )->addObject(
                                $invoice
                            )->addObject(
                                $invoice->getOrder()
                            );
                            $transactionSave->save();
                            $this->messageManager->addSuccess(__('Magento invoice has been created.'));
                            // send invoice/shipment emails
                            try {
//            if (!empty($data['send_email'])) {
                                $this->invoiceSender->send($invoice);
//            }
                            } catch (\Exception $e) {
                                $this->_objectManager->get(\Psr\Log\LoggerInterface::class)->critical($e);
                                $this->messageManager->addError(__('We can\'t send the invoice email right now.'));
                            }
                            $this->_objectManager->get(\Magento\Backend\Model\Session::class)->getCommentText(true);
                            return $resultRedirect->setPath('sales/order/view', ['order_id' => $orderId]);
                        } catch (LocalizedException $e) {
                            $this->messageManager->addError($e->getMessage());
                            return $resultRedirect->setPath('sales/order_invoice/new', ['order_id' => $orderId]);
                        } catch (\Exception $e) {
                            $this->messageManager->addError(__('We can\'t save the invoice right now.'));
                            $this->_objectManager->get(\Psr\Log\LoggerInterface::class)->critical($e);
                            return $resultRedirect->setPath('sales/order_invoice/new', ['order_id' => $orderId]);
                        }
                    }
                }
            } elseif (strtolower(trim($result->Response->ApprovalStatus)) == "expired") {
            $this->messageManager->addError(__('Order needs to be cancelled as the contracts on the lease ID has expired. '));
        } else {
            $this->messageManager->addError(__('Order cannot be scheduled as contracts are not signed. Please contact the customer to see if they are interested to continue.'));
        }
    } else
{
$this->messageManager->addError(__('Lease ID is missing.'));
}

$this->_objectManager->get(\Magento\Backend\Model\Session::class)->getCommentText(true);
return $resultRedirect->setPath('sales/order/view', ['order_id' => $orderId]);
}
}