<?php

namespace Conns\Yeslease\Controller\Checkout;
use Magento\Framework\App\Action\Context;

class Error extends \Magento\Framework\App\Action\Action
{
	 public function __construct(
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        Context $context
    )
    {
        $this->_pageFactory = $pageFactory;
        parent::__construct($context);
    }
	
    public function execute()
    {
		$this->_view->loadLayout();
        $this->_view->getLayout()->initMessages();
        $this->_view->renderLayout();
    }
}