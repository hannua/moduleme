<?php

namespace Conns\Yeslease\Controller\Checkout;

use Conns\Checkout\Controller\Ajax\Onepage;
use Magento\Framework\App\Action\Context;
use Magento\TestFramework\Event\Magento;

class Invoicequote extends \Magento\Framework\App\Action\Action
{
	
	const XML_PATH_PROGRESSIVE_QUOTE_LIMIT = 'payment/progressive/amount_restriction';
	const XML_PATH_PROGRESSIVE_APPROVAL_PERCENTAGE = 'payment/progressive/adjust_approval_amount';
    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;
	
	protected $scopeConfig;

    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $_checkoutSession;

    /**
     * @var \Conns\Restservices\Helper\Api
     */
    protected $_apiHelper;

    protected $_storeManager;

    /**
     * Invoice Quote constructor.
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Conns\Yeslease\Helper\Data $dataHelper
     * @param Context $context
     */
    public function __construct(
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Conns\Restservices\Helper\Api $apiHelper,
        \Conns\Yeslease\Helper\Data $dataHelper,
\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        Context $context
    )
    {
        $this->_customerSession = $customerSession;
        $this->_checkoutSession = $checkoutSession;
	$this->scopeConfig = $scopeConfig;
        $this->_storeManager = $storeManager;
        $this->_apiHelper = $apiHelper;
        $this->_dataHelper = $dataHelper;
        parent::__construct($context);
    }

    /**
     * @var Data
     */
    protected $_dataHelper;


    public function execute()
    {
        if ($this->getRequest()->isAjax()) {
            $returnArr = array();
            $errorResponse = false;
//                $leaseResponse = $this->_customerSession->getLeaseResponce();
            $customerID = $this->_checkoutSession->getConnsCustomerId();
            $quoteRequest = $this->_checkoutSession->getMyQuoteRequest();
            $leaseId = $this->_checkoutSession->getYesleaseApprovedNumber();
			$ylApprovedAmnt = $this->_checkoutSession->getYesleaseApprovedAmount(); //Arjun Code
			$quoteRequest->InvoicePayment->type = "EN";
            $quoteRequest->InvoicePayment->authorizationCode = $leaseId;
            $quoteRequest->Billing->connsCustomerId = $customerID;
            $response = $this->_apiHelper->__makeInvoiceNewCall($quoteRequest, 'Quote');
            if ($response && isset($response->status)
                && $response->status == Onepage::STATUS_SUCCESS
                && isset($response->Response)
            ) {
                $this->_checkoutSession->setMyQuoteResponse($response);
                $response = $response->Response;
                $connsQuoteId = isset($response->connsQuoteNumber) ? $response->connsQuoteNumber : '';
				$totalAmount = isset($response->InvoiceFooter->totalPaid) ? $response->InvoiceFooter->totalPaid : '';
				$storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
				$quotelimit	=	$this->scopeConfig->getValue(self::XML_PATH_PROGRESSIVE_QUOTE_LIMIT, $storeScope);
				$approvalPercentage	=	$this->scopeConfig->getValue(self::XML_PATH_PROGRESSIVE_APPROVAL_PERCENTAGE, $storeScope);
				$ylApprovedAmount	=	(($approvalPercentage*$ylApprovedAmnt)/100);
				$cartUrl	=	$this->_storeManager->getStore()->getUrl('checkout/cart');
                $this->_checkoutSession->setConnsCreditWorkSheetId($connsQuoteId);
                $this->_customerSession->setConnsCreditWorkSheetId($connsQuoteId);
				
				$paymentType	=	$this->getRequest()->getPost('paymentType');
				if(isset($paymentType) && (trim($paymentType)=='progressive')){
					$this->_checkoutSession->setYesleasePaymentType($paymentType);
				}

                if (!$connsQuoteId) {
                    $result['message'] = __('There was an error in processing data. Please contact us');
                    $response = ['error' => true, 'message' => $result['message']];
                    echo json_encode($response);
                    exit;
                }
				if ($totalAmount>=$ylApprovedAmount) {
                    $result['message'] = __("You are approved for $".$ylApprovedAmnt.". Please adjust your cart total to $".$ylApprovedAmount.". <a class='yl-edit-cart' href='".$cartUrl."'>Edit your cart</a>");
                    $response = ['error' => true, 'message' => $result['message']];
                    echo json_encode($response);
                    exit;
                }
				if ($quotelimit > $totalAmount){
                    $result['message'] = __("Your shopping cart value is lower than $".$quotelimit.". Please choose a different payment method or add/update your shopping cart.");
                    $response = ['error' => true, 'message' => $result['message']];
                    echo json_encode($response);
                    exit;
                }

                //need to set quote number to address so that we can populate to sales_order

                $quote = $this->_checkoutSession->getQuote();
                $quote->setConnsQuoteId($connsQuoteId);
                //need to set connsCustomerId
                if (isset($response->Billing) && isset($response->Billing->connsCustomerId)) {
                    $connsCustomerId = $this->setConnsCustomerIdToCustomer($response->Billing->connsCustomerId);
                    $quote->setConnsCustomerId($connsCustomerId);
                    $this->_checkoutSession->setConnsCustomerId($response->Billing->connsCustomerId);
                }
                //set conns Address ID to address
                $responseBilling = isset($response->Billing) ? $response->Billing : null;
                if (isset($responseBilling->Address) && isset($responseBilling->Address->connsAddressId)) {
                    $quote->getBillingAddress()->setConnsAddressId($responseBilling->Address->connsAddressId);
                    $quote->getBillingAddress()
                        ->setConnsAddressIdToAddress($responseBilling->Address->connsAddressId);
                }
                //shipping
                $responseShipping = isset($response->Shipping) ? $response->Shipping : null;
                if (isset($responseShipping->Address) && isset($responseShipping->Address->connsAddressId)) {
                    $quote->setConnsAddressId($responseShipping->Address->connsAddressId);
                    $quote->setConnsAddressIdToAddress($responseShipping->Address->connsAddressId);
                }
            } else {
                $result['message'] = __('There was an error in processing data. Please contact us');
                $response = ['error' => true, 'message' => $result['message']];
                echo json_encode($response);
                exit;
            }


            //need to have tax logic
            $this->_customerSession->setConnsQuoteResponse($response);
            $quote->setConnsQuoteResponse($response);
            $quote->getShippingAddress()->setCollectShippingRates(true);
            $quote->collectTotals();
            $quote->save();
			
            $response = ['error' => false, 'message' => 'success'];
            echo json_encode($response); // return response to ajax call in js file
        }
    }

    public function setConnsCustomerIdToCustomer($connsCustomerId)
    {
        $customer = $this->_customerSession->getCustomer();
        if ($customer && (!$customer->getConnsCustomerId()) && $this->_customerSession->isLoggedIn()) {
            //$connsCustomerId
            $customer->setConnsCustomerId($connsCustomerId);
            $customer->setSavedFromQuote(true);
            $customer->save();
            return $connsCustomerId;
        }

        return null;
    }

}