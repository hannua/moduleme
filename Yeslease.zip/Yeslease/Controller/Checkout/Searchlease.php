<?php

namespace Conns\Yeslease\Controller\Checkout;
use Magento\Framework\App\Action\Context;

class Searchlease extends \Magento\Framework\App\Action\Action
{
	/**
     * @var Data
     */
    protected $_dataHelper;
	
	/**
     * @var \Magento\Checkout\Model\Session $checkoutSession
     */
    protected $checkoutSession;
	 /**
     * Verify Lease constructor.
     * @param \Magento\Framework\View\Result\PageFactory $pageFactory
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Framework\Session\SessionManagerInterface $coreSession
     * @param Context $context
     */
    public function __construct(
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        \Magento\Customer\Model\Session $customerSession,
		\Conns\Yeslease\Helper\Data $dataHelper,
		\Magento\Checkout\Model\Session $checkoutSession,
        Context $context
    )
    {
        $this->_pageFactory = $pageFactory;
        $this->_customerSession = $customerSession;
		$this->_dataHelper = $dataHelper;
		$this->checkoutSession = $checkoutSession;
		parent::__construct($context);
    }



    public function execute()
    {
		if($this->getRequest()->isAjax()){
			$returnArr		=	array();
			$errorResponse 	= 	false;
			
			if($this->getRequest()->getPost()){
				$response 			= 	$this->_customerSession->getConnsQuoteResponse();
				$customerID			= 	$response->Billing->connsCustomerId;
				$connsQuoteNumber 	= 	isset($response->connsQuoteNumber) ? $response->connsQuoteNumber : '';
				$lastName 			= 	$response->Billing->lastName;
				$applicant_dob		=	$this->getRequest()->getPost('applicant_dob');
				$last4ssn			=	$this->getRequest()->getPost('applicant_lastfour_ssn');
				$birthYear			=	date('Y',strtotime($applicant_dob));
				$birthMonth			=	date('m',strtotime($applicant_dob));
				$writer 			= 	new \Zend\Log\Writer\Stream(BP . '/var/log/support_report_progressive.log');
				$logger 			= 	new \Zend\Log\Logger();
				$logger->addWriter($writer);									
				if(trim($applicant_dob) && (strlen(trim($last4ssn))==4)){
					$this->checkoutSession->setShowYesleaseSuccess('');
					$this->checkoutSession->setYesleasePaymentType('');
					$this->checkoutSession->setYesleaseTransactionID('');
					$this->checkoutSession->setYesleaseApprovedNumber('');
					$this->checkoutSession->setYesleaseEsignUrl('');
					$this->checkoutSession->setYesleaseApprovedAmount('');
					$this->checkoutSession->setYesleaseQuoteNumber('');
					$authResult =	$this->_dataHelper->__maketokenapicall();
					if ($authResult) {
						$authResult = json_decode($authResult);
						if (isset($authResult->access_token)) {
							$resobj = $this->_dataHelper->getSearchLease($authResult->access_token, $customerID, $lastName, $last4ssn, $birthMonth, $birthYear);
							if (!is_string($resobj) || $resobj == "") {
								$errorResponse = true;
							}

							$decodedRespobj = json_decode($resobj);
							if (is_string($resobj) && $resobj != "") {
								if (!is_object($decodedRespobj) && !is_array($decodedRespobj)) {
									$errorResponse = true;
								}

								if (is_array($decodedRespobj)) {
									if (trim($decodedRespobj['code']) != "200" || trim($decodedRespobj['data']) == "" || trim($decodedRespobj['data']) == null) {
										$errorResponse = true;
									}
									if (trim($decodedRespobj['code']) == "204"){
										$returnArr['status']	=	"error";
										$returnArr['msg']		=	"We could not locate your approved lease ID. Please review the information provided and try again.";
										$errorResponse = false;
									}
								}

							}


							if ($errorResponse) {
								if (!empty($decodedRespobj->message)) {
									$returnArr['status']	=	"error";
									$returnArr['error']		= __($decodedRespobj->message);
								}else{
									$returnArr['status']	=	"error";
									$returnArr['msg']		=	"There is some error in processing your request. Please try again.";
								}
								
							}else{
								$resobj = json_decode($resobj);
								if ($resobj->code == '200') {
									$resp = $resobj->data;
									if($resp){
										$leaseStatus	=	isset($resp->Status)? $resp->Status : '';
										$transactionID	=	isset($resp->TransactionID)? $resp->TransactionID : '';
										$leaseNumber	=	isset($resp->LeaseID)? $resp->LeaseID : '';
										$leaseDetails	=	isset($resp->LeaseDetails)? $resp->LeaseDetails : '';
										$approvedLimit	=	'';
										if(trim(strtolower($leaseStatus))=="approved"){
											$returnArr['status']	=	"success";
											$returnArr['msg']	=	"Your application has been verified. Your contracts will be presented after you submit the order. Please continue.";
											if($leaseDetails){
												$approvedLimit	=	isset($leaseDetails->ApprovalLimit)? $leaseDetails->ApprovalLimit : '';
												$returnArr['approvedamount']	=	$approvedLimit;
											}
											$this->checkoutSession->setYesleaseTransactionID($transactionID);
											$this->checkoutSession->setYesleaseApprovedNumber($leaseNumber);
											$this->checkoutSession->setYesleaseApprovedAmount($approvedLimit);
											$this->checkoutSession->setYesleaseQuoteNumber($connsQuoteNumber);
										}elseif(trim(strtolower($leaseStatus))=="contracts"){
											$returnArr['status']	=	"error";
											$returnArr['msg']	=	"The Lease ID entered has already been used on an order. Contact us at 1-866-765-1513 for any questions.";
										}elseif(trim(strtolower($leaseStatus))=="contracts received"){
											$returnArr['status']	=	"error";
											$returnArr['msg']	=	"The Lease ID entered has already been used on an order. Contact us at 1-866-765-1513 for any questions.";
										}else{
											$returnArr['status']	=	"error";
											$returnArr['msg']	=	"Date of Birth and SSN do not match our records. Verify your information and try again.";
										}
										
									}
								}elseif ($resobj->code == '204') {
								
									$returnArr['status']	=	"error";
									$returnArr['msg']		=	"Date of Birth and SSN do not match our records. Verify your information and try again.";
								
								}else{
									$returnArr['status']	=	"error";
									$returnArr['msg']		=	"Date of Birth and SSN do not match our records. Verify your information and try again.";
								}
							}
						}
						
					}
				
				}else{
					$returnArr['status']	=	"error";
					$returnArr['msg']		=	"Please select a valid date of birth and provide the last 4 digits of your SSN.";
				}
			}else{
				$returnArr['status']	=	"error";
				$returnArr['msg']		=	"Please select a valid date of birth and provide the last 4 digits of your SSN.";
			}
		}else{
			$returnArr['status']	=	"error";
			$returnArr['msg']		=	"There is some error in processing your request. Please try again.";
		}
		
		echo json_encode($returnArr);
		
        
    }
}