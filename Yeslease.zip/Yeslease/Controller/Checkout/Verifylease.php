<?php

namespace Conns\Yeslease\Controller\Checkout;
use Magento\Framework\App\Action\Context;

class Verifylease extends \Magento\Framework\App\Action\Action
{
	/**
     * @var Data
     */
    protected $_dataHelper;
	
	/**
     * @var \Magento\Checkout\Model\Session $checkoutSession
     */
    protected $checkoutSession;
	 /**
     * Verify Lease constructor.
     * @param \Magento\Framework\View\Result\PageFactory $pageFactory
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Framework\Session\SessionManagerInterface $coreSession
     * @param Context $context
     */
    public function __construct(
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        \Magento\Customer\Model\Session $customerSession,
		\Conns\Yeslease\Helper\Data $dataHelper,
		\Magento\Checkout\Model\Session $checkoutSession,
        Context $context
    )
    {
        $this->_pageFactory = $pageFactory;
        $this->_customerSession = $customerSession;
		$this->_dataHelper = $dataHelper;
		$this->checkoutSession = $checkoutSession;
		parent::__construct($context);
    }



    public function execute()
    {
		if($this->getRequest()->isAjax()){
			$returnArr		=	array();
			$errorResponse  = 	false;
			if($this->getRequest()->getPost()){
				$response 			= 	$this->_customerSession->getConnsQuoteResponse();
				$this->checkoutSession->setShowYesleaseSuccess('');
				$this->checkoutSession->setYesleasePaymentType('');
				$this->checkoutSession->setYesleaseTransactionID('');
				$this->checkoutSession->setYesleaseApprovedNumber('');
				$this->checkoutSession->setYesleaseEsignUrl('');
				$this->checkoutSession->setYesleaseApprovedAmount('');
				$this->checkoutSession->setYesleaseQuoteNumber('');
				
				$connsQuoteNumber 	= 	isset($response->connsQuoteNumber) ? $response->connsQuoteNumber : '';
				$customerID			= 	$response->Billing->connsCustomerId;
				$leaseNumber		=	$this->getRequest()->getPost('applicant_lease_number');
				$last4ssn			=	$this->getRequest()->getPost('applicant_lastfour_ssn');
				$writer 			= 	new \Zend\Log\Writer\Stream(BP . '/var/log/support_report_progressive.log');
				$logger 			= 	new \Zend\Log\Logger();
				$logger->addWriter($writer);									
				if((strlen(trim($leaseNumber))>=6) && (strlen(trim($last4ssn))==4)){
					
					$authResult =	$this->_dataHelper->__maketokenapicall();
					if ($authResult) {
						$authResult = json_decode($authResult);
						if (isset($authResult->access_token)) {
							$resobj = $this->_dataHelper->getVerifyLease($authResult->access_token, $customerID, $leaseNumber, $last4ssn);
							if (!is_string($resobj) || $resobj == "") {
								$errorResponse = true;
							}

							$decodedRespobj = json_decode($resobj);
							if (is_string($resobj) && $resobj != "") {
								if (!is_object($decodedRespobj) && !is_array($decodedRespobj)) {
									$errorResponse = true;
								}

								if (is_array($decodedRespobj)) {
									if (trim($decodedRespobj['code']) != "200" || trim($decodedRespobj['data']) == "" || trim($decodedRespobj['data']) == null) {
										$errorResponse = true;
									}
									if (trim($decodedRespobj['code']) == "204"){
										$returnArr['status']	=	"error";
										$returnArr['msg']		=	"We could not locate your approved lease ID. Please review the information provided and try again.";
										$errorResponse = false;
									}
								}

							}


							if ($errorResponse) {
								if (!empty($decodedRespobj->message)) {
									$returnArr['status']	=	"error";
									$returnArr['error']		= __($decodedRespobj->message);
								}else{
									$returnArr['status']	=	"error";
									$returnArr['msg']		=	"There is some error in processing your request. Please try again.";
								}
								
							}else{
								$resobj = json_decode($resobj);
								if ($resobj->code == '200') {
									$resp = $resobj->data;
									$this->_customerSession->setLeaseResponce($resp);
									if($resp){
										$leaseStatus	=	isset($resp->Status)? $resp->Status : '';
										$transactionID	=	isset($resp->TransactionID)? $resp->TransactionID : '';
										$leaseNumber	=	isset($resp->LeaseID)? $resp->LeaseID : '';
										$leaseDetails	=	isset($resp->LeaseDetails)? $resp->LeaseDetails : '';
										if(trim(strtolower($leaseStatus))=="approved"){
											$returnArr['status']	=	"success";
											$returnArr['msg']	=	"Your application has been verified. Your contracts will be presented after you submit the order. Please continue.";
											if($leaseDetails){
												$approvedLimit	=	isset($leaseDetails->ApprovalLimit)? $leaseDetails->ApprovalLimit : '';
												$returnArr['approvedamount']	=	$approvedLimit;
											}
											$this->checkoutSession->setYesleaseTransactionID($transactionID);
											$this->checkoutSession->setYesleaseApprovedNumber($leaseNumber);
											$this->checkoutSession->setYesleaseApprovedAmount($approvedLimit);
											$this->checkoutSession->setYesleaseQuoteNumber($connsQuoteNumber);
										}elseif(trim(strtolower($leaseStatus))=="contracts"){
											$returnArr['status']	=	"error";
											$returnArr['msg']	=	"The Lease ID entered has already been used on an order. Contact us at 1-866-765-1513 for any questions.";
										}elseif(trim(strtolower($leaseStatus))=="contracts received"){
											$returnArr['status']	=	"error";
											$returnArr['msg']	=	"The Lease ID entered has already been used on an order. Contact us at 1-866-765-1513 for any questions.";
										}else{
											$returnArr['status']	=	"error";
											$returnArr['msg']	=	"The Lease ID entered has already been used on an order. Contact us at 1-866-765-1513 for any questions.";
										}
										
									}
								}elseif ($resobj->code == '204') {
								
									$returnArr['status']	=	"error";
									$returnArr['msg']		=	"We could not locate your approved lease ID. Please review the information provided and try again.";
								
								}else{
									$returnArr['status']	=	"error";
									$returnArr['msg']		=	"There is some error in processing your request. Please try again.";
								}
							}
						}
						
					}
				
				}else{
					$returnArr['status']	=	"error";
					$returnArr['msg']		=	"Please enter a valid 6 digit lease ID and last 4 digits of your SSN.";
				}
			}else{
				$returnArr['status']	=	"error";
				$returnArr['msg']		=	"Please enter the information requested.";
			}
		}else{
			$returnArr['status']	=	"error";
			$returnArr['msg']		=	"There is some error in processing your request. Please try again.";
		}
		
		echo json_encode($returnArr);
		
        
    }
}