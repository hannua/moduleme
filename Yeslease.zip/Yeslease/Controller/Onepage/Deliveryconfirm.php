<?php

namespace Conns\Yeslease\Controller\Onepage;
use Magento\Framework\App\Action\Context;
use Conns\Restservices\Helper\Restobj;
use Magento\Sales\Model\Order;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\Order\Email\Sender\InvoiceSender;

class Deliveryconfirm extends \Magento\Framework\App\Action\Action
{
	/**
     * @var Data
     */
    protected $_dataHelper;
	
	/**
     * @var \Magento\Checkout\Model\Session $checkoutSession
     */
    protected $checkoutSession;
	
	/**
     * @var Order
     */
    protected $_order;
	 /**
     * Verify Lease constructor.
     * @param \Magento\Framework\View\Result\PageFactory $pageFactory
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Framework\Session\SessionManagerInterface $coreSession
     * @param Context $context
     */
    public function __construct(
		Order $order,
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        \Magento\Customer\Model\Session $customerSession,
		\Conns\Yeslease\Helper\Data $dataHelper,
		\Magento\Checkout\Model\Session $checkoutSession,
		\Magento\Framework\App\Request\Http $request,
		OrderRepositoryInterface $orderRepository,
        Restobj $restobj,
        \Magento\Sales\Model\Service\InvoiceService $invoiceService,
        InvoiceSender $invoiceSender,
        Context $context
    )
    {
		$this->_order       = $order;
		$this->request = $request;
        $this->_pageFactory = $pageFactory;
        $this->_customerSession = $customerSession;
		$this->_dataHelper = $dataHelper;
		$this->checkoutSession = $checkoutSession;
		$this->orderRepository = $orderRepository;
        $this->restobj = $restobj;
        $this->invoiceService = $invoiceService;
        $this->invoiceSender = $invoiceSender;
		parent::__construct($context);
    }



    public function execute()
    {
		//if($this->getRequest()->isAjax()){

			$checkout_trans_id 	= 	$this->checkoutSession->getYesleaseTransactionID();
			$lease_number 		= 	$this->checkoutSession->getYesleaseApprovedNumber();
			$payment_type 		= 	$this->checkoutSession->getYesleasePaymentType();
			if($lease_number && ($payment_type=='progressive')){
				$writer 			= 	new \Zend\Log\Writer\Stream(BP . '/var/log/support_report_progressive.log');
				$logger 			= 	new \Zend\Log\Logger();
				$logger->addWriter($writer);	
				$errorResponse 		= 	false;
				$successResponse 	= 	false;
				$returnArr		=	array();
				$authResult =	$this->_dataHelper->__maketokenapicall();
				if ($authResult) {
					$authResult = json_decode($authResult);
					
					if (isset($authResult->access_token)) {
						$resobj = $this->_dataHelper->_makeDelivconfirmCall($authResult->access_token, $lease_number);
						$logger->info('Response from Delivery Confirm' . print_r($resobj, true));
						if (!is_string($resobj) || $resobj == "") {
							$errorResponse = true;
						}

						$decodedRespobj = json_decode($resobj);
						if (is_string($resobj) && $resobj != "") {
							if (!is_object($decodedRespobj) && !is_array($decodedRespobj)) {
								$errorResponse = true;
							}

							if (is_array($decodedRespobj)) {
								if (trim($decodedRespobj['code']) != "200" || trim($decodedRespobj['data']) == "" || trim($decodedRespobj['data']) == null) {
									$errorResponse = true;
								}
								
							}
						}
						if (!$errorResponse) {
							$resobj = json_decode($resobj);
							if ($resobj->code == '200') {
								$resp = $resobj->data;
								if($resp){
									$leaseStatus	=	isset($resp->ApprovalStatus)? $resp->ApprovalStatus : '';
									$approved_limit	=	isset($resp->ApprovalLimit)? $resp->ApprovalLimit : '';
									$leaseNumber	=	isset($resp->LeaseID)? $resp->LeaseID : '';
									$esignUrl		=	isset($resp->EsignUrl)? $resp->EsignUrl : '';
									$merchandise	=	isset($resp->OkayToDeliver)? $resp->OkayToDeliver : '';
									$approvedLimit	=	'';
									$logger->info('Delivery Confirm page' .$merchandise);
									$logger->info('Delivery Confirm page' .$leaseStatus);
									$logger->info('Delivery Confirm page' .$leaseNumber);
									if(($leaseNumber) && ($approved_limit>0) && ($merchandise=='true') && ((trim(strtolower($leaseStatus))=="contracts received") || (trim(strtolower($leaseStatus))=="funded") )){
										$orderId = $this->checkoutSession->getData('last_order_id');
										$order = $this->orderRepository->get($orderId);
										
										if($esignUrl){
											//update esign in db
											//update status for order
										}
										$errorResponse   = false;
										if(!$errorResponse){
											
											if (!$order->getId()) {
												throw new \Magento\Framework\Exception\LocalizedException(__('The order no longer exists.'));
												$logger->info('The order no longer exists.' . print_r($orderId, true));
											}
											$response = $this->restobj->invoiceNewForSalesOrder($order);
											if (empty($response->Response->connsInvoiceNumber)) {
                                                $response->Response->connsInvoiceNumber = $this->checkoutSession->getYesleaseQuoteNumber();
											}
                                            $this->checkoutSession->setConnsPlaceOrder($response);
											$logger->info('Invoice Create API Response.' . print_r($response, true));
											if ($response && isset($response->status)
												&& $response->status == Restobj::STATUS_SUCCESS
												&& isset($response->Response)
											) {
												try {
													$logger->info('oRDER id.' . print_r($orderId, true));
													$logger->info('Order ID' . print_r($order->getId(), true));

													$logger->info('Invoice Quote number.' . print_r($response->Response->connsInvoiceNumber, true));
													$order->setConnsInvoiceId($response->Response->connsInvoiceNumber);
													$order->setConnsQuoteId($response->Response->connsQuoteNumber);
													$order->setConnsCustomerId($response->Response->Billing->connsCustomerId);
													$order->setWarranty($this->checkoutSession->getwarrantyPriceCach());
													date_default_timezone_set("America/Chicago");
													$state 			= "approvedyesmoney";													 $orderStatus 	= "docusign_complete";
													$timeNow 		= date('Y-m-d H:i:s', strtotime("now"));
													$comment     	= "Order state changed at: " . $timeNow;
													$order->setState($state);
													$order->setStatus($orderStatus);
													$order->addStatusToHistory($orderStatus, $comment, false);
													if($id	=	$order->save()){
													$logger->info('saved' . print_r($id->getId(), true));
													}else{
													$logger->info('Not saved');
													}
													
													if (!$order->canInvoice()) {
														throw new \Magento\Framework\Exception\LocalizedException(
															__('The order does not allow an invoice to be created.')
														);
														$logger->info('The order does not allow an invoice to be created.' . print_r($orderId, true));
													}
													$invoice = $this->invoiceService->prepareInvoice($order);

													if (!$invoice) {
														throw new LocalizedException(__('We can\'t save the invoice right now.'));
														$logger->info('We can\'t save the invoice right now.' . print_r($orderId, true));
													}

													if (!$invoice->getTotalQty()) {
														throw new \Magento\Framework\Exception\LocalizedException(
															__('You can\'t create an invoice without products.')
														);
														$logger->info('You can\'t create an invoice without products.' . print_r($orderId, true));
													}
													$invoice->register();

													$invoice->getOrder()->setCustomerNoteNotify(false);
													$invoice->getOrder()->setIsInProcess(true);

													$transactionSave = $this->_objectManager->create(
														\Magento\Framework\DB\Transaction::class
													)->addObject(
														$invoice
													)->addObject(
														$invoice->getOrder()
													);
													$transid	=	$transactionSave->save();
													
													// send invoice/shipment emails
													try {
														if($transid){
															$successResponse = true;
															$this->checkoutSession->setShowYesleaseSuccess('yes');
															//$this->invoiceSender->send($invoice);
															$returnArr['status']	=	'success';
																
														}
														
													} catch (\Exception $e) {
														$this->_objectManager->get(\Psr\Log\LoggerInterface::class)->critical($e);
														$logger->info('Exception' . print_r($e->getMessage(), true));
													}
													
													
												} catch (LocalizedException $e) {
													$logger->info('We can\'t save the invoice right now.' . print_r($e->getMessage(), true));
												} catch (\Exception $e) {
													$this->messageManager->addError(__('We can\'t save the invoice right now.'));
													$logger->info('We can\'t save the invoice right now.' . print_r($e->getMessage(), true));
												}
											}else{
												$logger->info('We dont have success response of invoice create api.' . print_r($orderId, true));
											}
										}
									}else{
										$returnArr['status']	=	'return';
									}
								}else{
									$errorResponse = true;	
								}
							}else{
								$errorResponse = true;
							}
						}else{
							$errorResponse = true;
						}
					}else{
						$errorResponse = true;
					}
				
				}else{
					$errorResponse = true;
				}
			}else{
				$errorResponse = true;
			}
		//}
		
		if($errorResponse){
			$this->checkoutSession->setShowYesleaseSuccess('no');
			$returnArr['status']	=	'error';
		}
		echo json_encode($returnArr);
	}
        
    
}