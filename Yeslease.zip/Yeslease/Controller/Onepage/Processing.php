<?php

namespace Conns\Yeslease\Controller\Onepage;
use Magento\Framework\App\Action\Context;

class Processing extends \Magento\Framework\App\Action\Action
{
	/**
     * @var Data
     */
    protected $_dataHelper;
	
	/**
     * @var \Magento\Checkout\Model\Session $checkoutSession
     */
    protected $checkoutSession;
	 /**
     * Verify Lease constructor.
     * @param \Magento\Framework\View\Result\PageFactory $pageFactory
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Framework\Session\SessionManagerInterface $coreSession
     * @param Context $context
     */
    public function __construct(
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        \Magento\Customer\Model\Session $customerSession,
		\Conns\Yeslease\Helper\Data $dataHelper,
		\Magento\Checkout\Model\Session $checkoutSession,
        Context $context
    )
    {
        $this->_pageFactory = $pageFactory;
        $this->_customerSession = $customerSession;
		$this->_dataHelper = $dataHelper;
		$this->checkoutSession = $checkoutSession;
		parent::__construct($context);
    }



    public function execute()
    {
		$refid				=	$this->getRequest()->getParam('refid'); 
		$trans_id			=	trim(base64_decode($refid));
		$checkout_trans_id 	= 	$this->checkoutSession->getYesleaseTransactionID();
		$lease_number 		= 	$this->checkoutSession->getYesleaseApprovedNumber();
		$payment_type 		= 	$this->checkoutSession->getYesleasePaymentType();
		$isYesLeaseSuccess	=	$this->checkoutSession->getShowYesleaseSuccess();
		$writer 			= 	new \Zend\Log\Writer\Stream(BP . '/var/log/support_report_progressive.log');
		$logger 			= 	new \Zend\Log\Logger();
		$logger->addWriter($writer);	
		$logger->info("Entry on processing page");
		$logger->info("Processing page Transaction ID: ".$checkout_trans_id);
		$logger->info("Processing page Lease Number: ".$lease_number);
		$logger->info("Processing page Payment Type: ".$payment_type);
		if(($trans_id	==	$checkout_trans_id) && ($lease_number) && ($payment_type=='progressive') && ($isYesLeaseSuccess !='yes')){
			$this->checkoutSession->setShowYesleaseSuccess('yes');
			$this->checkoutSession->setYesleaseEsignUrl('');
			$resultPage = 	$this->_pageFactory->create();
			$resultPage->getConfig()->getTitle()->set("Progressive Order Processing");
			$resultPage->getConfig()->setDescription("Get our Lowest Payment, Tailored to You. Apply online. Good Credit or building credit, we'll work with you to Make It Happen.");
			$resultPage->getConfig()->setKeywords("Conns HomePlus, Low Payment Finder, Credit Application");
			$this->_view->loadLayout();
			$this->_view->getLayout()->initMessages();
			$this->_view->renderLayout();
			
		}else{
			$logger->info("Direct hit of URL in browser, no Action redirect to cart page");
			$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
			$storeManager = $objectManager->get('\Magento\Store\Model\StoreManagerInterface');
			$url	=	$storeManager->getStore()->getUrl('checkout/cart');
			$this->getResponse()->setRedirect($url);
		}
		
        
    }
}