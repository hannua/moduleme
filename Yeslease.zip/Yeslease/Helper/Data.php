<?php
/**
 * Conns
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@magentocommerce.com so we can send you a copy immediately.
 * @category    Conns
 * @package     ${Global_Module_Name}
 * @author      Anom Khobragade
 * @copyright   Copyright (c) 2017 Conns (http://www.conns.com)
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Conns\Yeslease\Helper;
  use Magento\Framework\Stdlib\DateTime\TimezoneInterface;  
use Magento\Sales\Model\Order\Email\Container\CreditmemoIdentity;
use Conns\Catalog\Model\Product;
use Conns\Docusign\Model\Standard;
use Conns\Locator\Model\LocationFactory;
use Conns\Sales\Helper\Data as HelperData;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Email\Model\TemplateFactory as EmailMailerFactory;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\App\ObjectManager;
use Magento\Quote\Model\QuoteFactory;
use Magento\Sales\Model\Order;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\Store;
use Magento\Store\Model\StoreManagerInterface;


class Data extends AbstractHelper
{
    
	
	protected $ScopeInterface;
/**
* @var \Magento\Framework\App\Filesystem\DirectoryList
*/
protected $_directoryList;
/**
* @var StoreManagerInterface
*/
protected $modelStoreManagerInterface;

/**
* @var CacheInterface
*/
protected $appCacheInterface;

/**
* @var ScopeConfigInterface
*/
protected $storeConfig;

/**
* @var TransportBuilder
*/
protected $templateMailerFactory;

/**
* @var EmailMailerFactory
*/
protected $emailTemplateFactory;

/**
* @var QuoteFactory
*/
protected $modelQuoteFactory;

/**
* @var Store
*/
protected $modelStore;

/**
* @var HelperData
*/
protected $helperData;

/**
* @var LocationFactory
*/
protected $modelLocationFactory;

/**
* @var \Magento\Framework\Pricing\Helper\Data
*/
protected $_pricingHelperData;

/**
* @var TimezoneInterface
*/
protected $_timezone;

protected $checkoutSession;
protected $customerSession;

protected $_inlineTranslation;

    /**
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    protected $_transportBuilder;
    /**
     * Yeslease constructor.
     * @param \Magento\Framework\App\Filesystem\DirectoryList $directoryList
     * @param Context $context
     */
    public function __construct(
        \Magento\Framework\App\Filesystem\DirectoryList $directoryList,
		\Magento\Framework\App\Request\Http $request,

\Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone,
\Magento\Checkout\Model\Session $checkoutSession,
\Magento\Customer\Model\Session $customerSession,
\Magento\Framework\Pricing\Helper\Data $pricingHelperData,
Context $context,
StoreManagerInterface $modelStoreManagerInterface, 
CacheInterface $appCacheInterface,
ScopeConfigInterface $storeConfig, 
TransportBuilder $templateMailerFactory,
EmailMailerFactory $emailTemplateFactory, 
QuoteFactory $modelQuoteFactory, 
Store $modelStore, 
HelperData $helperData, 
LocationFactory $modelLocationFactory,
\Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder
    )
    {
		$this->request = $request;
        $this->_directoryList = $directoryList;
    $this->_timezone = $timezone;
    $this->checkoutSession = $checkoutSession;
	$this->customerSession = $customerSession;
	
    $this->_pricingHelperData = $pricingHelperData;
    $this->modelStoreManagerInterface = $modelStoreManagerInterface;
    $this->appCacheInterface = $appCacheInterface;
    $this->storeConfig = $storeConfig;
    $this->templateMailerFactory = $templateMailerFactory;
    $this->emailTemplateFactory = $emailTemplateFactory;
    $this->modelQuoteFactory = $modelQuoteFactory;
    $this->modelStore = $modelStore;
    $this->helperData = $helperData;
    $this->modelLocationFactory = $modelLocationFactory;
	$this->_inlineTranslation = $inlineTranslation;
        $this->_transportBuilder = $transportBuilder;
    
        parent::__construct($context);
    }

 public function getDelivconfirmStatus($leaseID)
    {
        $errorResponse = false;
        $responseObject = new \stdClass();
        $errorResponseObject = new \stdClass();
        $errorResponseObject->status = 0;
        $errorResponseObject->errorCode = "Y";
        $errorResponseObject->errorDescription = __('Internal Server Error.');

        $authResult = trim($this->__maketokenapicall());
        if ($authResult) {
            $authResult = json_decode($authResult);
            if (isset($authResult->access_token)) {
                $resobj = trim($this->_makeLeaseDetailsCall($authResult->access_token, $leaseID));
            }
        }
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/support_progressive.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info('Response from Mule -resobj' . $resobj);


        if (!is_string($resobj) || $resobj == "") {
            $errorResponse = true;
        }

        $decodedRespobj = json_decode($resobj);
        if (is_string($resobj) && $resobj != "") {
            if (!is_object($decodedRespobj) && !is_array($decodedRespobj)) {
                $errorResponse = true;
            }

            if (is_array($decodedRespobj)) {
                if (trim($decodedRespobj['code']) != "200" || trim($decodedRespobj['data']) == "" || trim($decodedRespobj['data']) == null) {
                    $errorResponse = true;
                }
            }

            if (is_object($decodedRespobj)) {
                if ($decodedRespobj->code != "200" || $decodedRespobj->data == "" || $decodedRespobj->data == null) {
                    $errorResponse = true;
                }
            }
        }


        if ($errorResponse) {
            if (!empty($decodedRespobj->message)) {
                $errorResponseObject->errorDescription = __($decodedRespobj->message);
            }
            return $errorResponseObject;
        }

        if ($resobj) {
            $resobj = json_decode($resobj);

            $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/support_progressive.log');
            $logger = new \Zend\Log\Logger();
            $logger->addWriter($writer);
            $logger->info('Response from Mule -resobj -- decode' . print_r($resobj, true));

            if ($resobj->code == '200') {
                $responseObject->status = 1;
                $responseObject->errorCode = "";
                $responseObject->errorDescription = "";
                $resp = $resobj->data;
//                $resp = $this->helperData->getDecryptedValue($resp);
//                $this->helperData->connsRestServicelogger('REST response from api starts');
//                $this->helperData->connsRestServicelogger($resp);
//                $this->helperData->connsRestServicelogger('REST response from api ends');

//                $resp = $this->changeRequest($resp);
                $responseObject->Response = $resp;
            } else {
                $responseObject->status = 0;
                $responseObject->errorCode = $resobj->code;
                $responseObject->errorDescription = $resobj->message;
            }

//            $this->helperData->connsRestServicelogger($responseObject);
            return $responseObject;
        }
        return $errorResponseObject;

    }

    /***
    Module: Yeslease
	Method: getVerifyLease: get verify Lease API
     **/
	public function getVerifyLease($token, $customerID, $leaseNumber, $last4ssn){

        $enablelog	=	$this->scopeConfig->getValue('payment/progressive/enable_logs');
		$apiUrl		=	"";
		$sslCert	=	"";
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/support_report_progressive.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);

		if($this->scopeConfig->getValue('payment/progressive/is_live')==1)
        {
            $apiUrl 	=  $this->scopeConfig->getValue('payment/progressive/live_api_url');
			$sslCert	=  $this->_directoryList->getPath('pub') . "/eai.conns.com.cert";
        }
        else
        {
            $apiUrl 	=  $this->scopeConfig->getValue('payment/progressive/stage_api_url');
			$sslCert	=  $this->_directoryList->getPath('pub') . "/connskeystore.crt";
        }

		$last4ssn	=   $this->getconnsEncrypt256Value($last4ssn);
        $data = array(
            "CustomerID" => "$customerID",
            "LeaseID" => "$leaseNumber",
            "Last4SSN" => "$last4ssn"
        );

        $jsonData = json_encode($data);
        $apiUrl		.=	'yeslease/verify/lease';
		if($enablelog==1){
            $logger->info("Verify Lease API Url: ".$apiUrl);
			$logger->info(print_r($data, true));
        }

        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS,$jsonData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FAILONERROR, false);
        curl_setopt($ch, CURLOPT_HTTP200ALIASES, array(400));
        curl_setopt($ch, CURLOPT_HTTP200ALIASES, array(500));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                "Content-Type: application/json",
                "Cache-Control: no-cache",
                "Authorization:Bearer $token")
        );
        curl_setopt($ch, CURLOPT_TIMEOUT, 45);

        $result = curl_exec($ch);
        if($enablelog==1){
            $logger->info(print_r($result, true));
        }
        if(!$result){
            if($enablelog==1){
                $this->_logger->info('CURL ERROR:', (array)curl_error($ch));
                $logger->info(print_r(curl_error($ch), true));

            }
        }
        return $result;
    }
	
	/***
    Module: Yeslease
	Method: SearchLease: get Lease ID by by DOB and SSN
     **/
	public function getSearchLease($token, $customerID, $lastName, $last4ssn, $birthMonth, $birthYear){

        $enablelog	=	$this->scopeConfig->getValue('payment/progressive/enable_logs');
		$apiUrl		=	"";
		$sslCert	=	"";
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/support_report_progressive.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);

		if($this->scopeConfig->getValue('payment/progressive/is_live')==1)
        {
            $apiUrl 	=  $this->scopeConfig->getValue('payment/progressive/live_api_url');
			$sslCert	=  $this->_directoryList->getPath('pub') . "/eai.conns.com.cert";
        }
        else
        {
            $apiUrl 	=  $this->scopeConfig->getValue('payment/progressive/stage_api_url');
			$sslCert	=  $this->_directoryList->getPath('pub') . "/connskeystore.crt";
        }

		$last4ssn	=   $this->getconnsEncrypt256Value($last4ssn);
        $data = array(
            "CustomerID" => "$customerID",
            "LastName" => "$lastName",
			"Last4SSN" => "$last4ssn",
			"BirthMonth" => "$birthMonth",
			"BirthYear"=> "$birthYear"
		);

        $jsonData = json_encode($data);
        $apiUrl		.=	'yeslease/search/lease';
		if($enablelog==1){
            $logger->info("Search Lease API Url: ".$apiUrl);
			$logger->info(print_r($data, true));
        }

        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS,$jsonData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FAILONERROR, false);
        curl_setopt($ch, CURLOPT_HTTP200ALIASES, array(400));
        curl_setopt($ch, CURLOPT_HTTP200ALIASES, array(500));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                "Content-Type: application/json",
                "Cache-Control: no-cache",
                "Authorization:Bearer $token")
        );
        curl_setopt($ch, CURLOPT_TIMEOUT, 45);

        $result = curl_exec($ch);
        if($enablelog==1){
            $logger->info(print_r($result, true));
        }
        if(!$result){
            if($enablelog==1){
                $this->_logger->info('CURL ERROR:', (array)curl_error($ch));
                $logger->info(print_r(curl_error($ch), true));

            }
        }
        return $result;
    }


    public function __maketokenapicall()
    {
        $apiUrl = '';
        $data = array();
        $authcode = '';
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/support_progressive.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);

        if ($this->scopeConfig->getValue('payment/progressive/is_live') == 1) {

            $apiUrl = $this->scopeConfig->getValue('payment/progressive/live_api_url');
            $data = array("grant_type" => "password",
                "username" => $this->scopeConfig->getValue('payment/progressive/live_api_username'),
                "password" => $this->scopeConfig->getValue('payment/progressive/live_api_password'),
                "scope" => "CREDITAPP_API");
            $authcode = base64_encode($this->scopeConfig->getValue('payment/progressive/live_api_auth_header'));

        } else {

            $apiUrl = $this->scopeConfig->getValue('payment/progressive/stage_api_url');
            $data = array("grant_type" => "password",
                "username" => $this->scopeConfig->getValue('payment/progressive/stage_api_username'),
                "password" => $this->scopeConfig->getValue('payment/progressive/stage_api_password'),
                "scope" => "YESLEASE_API");
            $authcode = base64_encode($this->scopeConfig->getValue('payment/progressive/stage_api_auth_header'));

        }

        $data_string = http_build_query($data);
        $apiUrl .= 'oauth/token?' . $data_string;
        if ($this->scopeConfig->getValue('payment/progressive/enable_logs') == 1) {
            $logger->info("progressive Auth API URL:" . $apiUrl);
        }
        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FAILONERROR, false);
        curl_setopt($ch, CURLOPT_HTTP200ALIASES, array(400));
        curl_setopt($ch, CURLOPT_HTTP200ALIASES, array(500));
        curl_setopt($ch, CURLOPT_TIMEOUT, 25);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                "Content-Type: application/x-www-form-urlencoded",
                "Cache-Control: no-cache",
                "Authorization: Basic $authcode"
            )
        );
        $result = curl_exec($ch);
        if ($this->scopeConfig->getValue('payment/progressive/enable_logs') == 1) {
            $logger->info(print_r($result, true));
        }
        if ($result) {

        } else {
            if ($this->scopeConfig->getValue('payment/progressive/enable_logs') == 1) {
                $logger->info(print_r(curl_error($ch), true));
            }
        }
        return $result;
    }

    public function _makeLeaseDetailsCall($token, $leaseID)
    {
        $apiUrl="";
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/support_progressive.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        if($this->scopeConfig->getValue('payment/progressive/is_live')==1)
        {
            $apiUrl =  $this->scopeConfig->getValue('payment/progressive/live_api_url');
        }
        else
        {
            $apiUrl =  $this->scopeConfig->getValue('payment/progressive/stage_api_url');
        }
        $apiUrl = $apiUrl."yeslease/request/details/lease/".$leaseID;
        $logger->info(print_r($apiUrl, true));

        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FAILONERROR, false);
        curl_setopt($ch, CURLOPT_HTTP200ALIASES, array(400));
        curl_setopt($ch, CURLOPT_HTTP200ALIASES, array(500));
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                "Content-Type: application/x-www-form-urlencoded",
                "Cache-Control: no-cache",
                "Authorization:Bearer $token")
        );
        curl_setopt($ch, CURLOPT_TIMEOUT, 45);

        $result = curl_exec($ch);
        if($this->scopeConfig->getValue('payment/progressive/enable_logs')==1){
            $logger->info(print_r($result, true));
        }
        if(!$result){
            if($this->scopeConfig->getValue('payment/progressive/enable_logs')==1){
                $this->_logger->info('CURL ERROR:', (array)curl_error($ch));
                $logger->info(print_r(curl_error($ch), true));

            }
        }
        return $result;
    }

    public function _makeDelivconfirmCall($token, $leaseID)
    {
        $apiUrl="";
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/support_progressive.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        if($this->scopeConfig->getValue('payment/progressive/is_live')==1)
        {
            $apiUrl =  $this->scopeConfig->getValue('payment/progressive/live_api_url');
        }
        else
        {
            $apiUrl =  $this->scopeConfig->getValue('payment/progressive/stage_api_url');
        }
        $apiUrl = $apiUrl."yeslease/request/deliveryconfirm/lease/".$leaseID;
        $logger->info(print_r($apiUrl, true));

        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FAILONERROR, false);
        curl_setopt($ch, CURLOPT_HTTP200ALIASES, array(400));
        curl_setopt($ch, CURLOPT_HTTP200ALIASES, array(500));
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                "Content-Type: application/x-www-form-urlencoded",
                "Cache-Control: no-cache",
                "Authorization:Bearer $token")
        );
        curl_setopt($ch, CURLOPT_TIMEOUT, 45);

        $result = curl_exec($ch);
        if($this->scopeConfig->getValue('payment/progressive/enable_logs')==1){
            $logger->info(print_r($result, true));
        }
        if(!$result){
            if($this->scopeConfig->getValue('payment/progressive/enable_logs')==1){
                $this->_logger->info('CURL ERROR:', (array)curl_error($ch));
                $logger->info(print_r(curl_error($ch), true));

            }
        }
        return $result;
    }
	
	public function getCancelLeaseStatus($leaseID){
        $authResult = trim($this->__maketokenapicall());
        if ($authResult){
            $authResult = json_decode($authResult);
            if (isset($authResult->access_token)){
                $resobj = trim($this->_makeCancelLeaseCall($authResult->access_token, $leaseID));
            }
        }
		if ($resobj){
			$writer = new \Zend\Log\Writer\Stream(BP . '/var/log/support_progressive.log');
			$logger = new \Zend\Log\Logger();
			$logger->addWriter($writer);
			$logger->info('Response from Mule cancel lease api' . $resobj);
            return json_decode($resobj);
        }
    }
	
	public function _makeCancelLeaseCall($token, $leaseID){
        $apiUrl="";
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/support_progressive.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        if($this->scopeConfig->getValue('payment/progressive/is_live')==1){
            $apiUrl =  $this->scopeConfig->getValue('payment/progressive/live_api_url');
        }
        else{
            $apiUrl =  $this->scopeConfig->getValue('payment/progressive/stage_api_url');
        }
        $apiUrl = $apiUrl."yeslease/cancel/lease/".$leaseID;
        $logger->info(print_r($apiUrl, true));
        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST"); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FAILONERROR, false);
        curl_setopt($ch, CURLOPT_HTTP200ALIASES, array(400));
        curl_setopt($ch, CURLOPT_HTTP200ALIASES, array(500));
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                "Content-Type: application/x-www-form-urlencoded",
                "Cache-Control: no-cache",
                "Authorization:Bearer $token")
        );
        curl_setopt($ch, CURLOPT_TIMEOUT, 45);
        $result = curl_exec($ch);
        if($this->scopeConfig->getValue('payment/progressive/enable_logs')==1){
            $logger->info(print_r($result, true));
        }
        if(!$result){
            if($this->scopeConfig->getValue('payment/progressive/enable_logs')==1){
                $this->_logger->info('CURL ERROR:', (array)curl_error($ch));
                $logger->info(print_r(curl_error($ch), true));
            }
        }
        return $result;
    }

     /**
     * @param $value
     * @return string
     */
    protected function getconnsEncrypt256Value($value ){
		$key	=	'';
		if($this->scopeConfig->getValue('payment/progressive/is_live')==1){
			$key = $this->scopeConfig->getValue('payment/progressive/live_encrypt_key');
		}else{
			$key = $this->scopeConfig->getValue('payment/progressive/stage_encrypt_key');
		}
        $value = utf8_encode($value);
        $encoded = base64_encode(
            openssl_encrypt($value, "aes-256-cbc", $key, true,str_repeat(chr(0), 16)));
        return rtrim(strtr($encoded, '+/', '-_'), '=');
    }
	
	
	public function submitInvoiceApi($token, $quoteObject)
	{
		$apiUrl		=	"";
		$sslCert	=	"";
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/support_progressive.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        if($this->scopeConfig->getValue('payment/progressive/is_live')==1)
        {
            $apiUrl =  $this->scopeConfig->getValue('payment/progressive/live_api_url');
			$sslCert	=  $this->_directoryList->getPath('pub') . "/eai.conns.com.cert";
        }
        else
        {
            $apiUrl =  $this->scopeConfig->getValue('payment/progressive/stage_api_url');
			$sslCert	=  $this->_directoryList->getPath('pub') . "/connskeystore.crt";
        }
        $apiUrl = $apiUrl."yeslease/submit/invoice";
		if($this->scopeConfig->getValue('payment/progressive/enable_logs')==1){
			  
		    $logger->info(print_r($apiUrl, true));
			$logger->info(print_r($quoteObject, true));
		}

        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS,$quoteObject);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FAILONERROR, false);
        curl_setopt($ch, CURLOPT_HTTP200ALIASES, array(400));
        curl_setopt($ch, CURLOPT_HTTP200ALIASES, array(500));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                "Content-Type: application/json",
                "Cache-Control: no-cache",
                "Authorization:Bearer $token")
        );
        curl_setopt($ch, CURLOPT_TIMEOUT, 45);

        $result = curl_exec($ch);
        if($this->scopeConfig->getValue('payment/progressive/enable_logs')==1){
            $logger->info(print_r($result, true));
        }
        if(!$result){
            if($this->scopeConfig->getValue('payment/progressive/enable_logs')==1){
                $this->_logger->info('CURL ERROR:', (array)curl_error($ch));
                $logger->info(print_r(curl_error($ch), true));

            }
        }
        return $result;
	}
	
	protected function prepareRequestForsubmitInvoice($InvoiceDetails){
	  
	    $items_sku 			= 	array();
		$count				=	0;
		if(count($InvoiceDetails)>0){
			foreach ($this->checkoutSession->getQuote()->getAllItems() as $item) {
				$items_sku[$count]['sku'] = $item->getSku();
				$items_sku[$count]['name'] = $item->getName();
				$count++;
			}
			for($i=0;$i<count($InvoiceDetails);$i++)
			{
				$conns_sku = $InvoiceDetails[$i]->connsSku;
				$quantity = $InvoiceDetails[$i]->quantity;
				if(isset($items_sku[$i]['sku']) && $InvoiceDetails[$i]->connsSku == $items_sku[$i]['sku'])
				{
					$price_total = $InvoiceDetails[$i]->unitPrice + $InvoiceDetails[$i]->installation->Price + $InvoiceDetails[$i]->warrantyInfo->Price;
					$product_name = $items_sku[$i]['name'];
					$unit_price = $InvoiceDetails[$i]->unitPrice;
					$item = array(
								"SKU" => "$conns_sku",
								"Model" => "$conns_sku",
								"Description" => "$product_name",
								"PriceEach" => "$price_total",
								"Quantity" => "$quantity"
					);
				}
				if($InvoiceDetails[$i]->connsSku == 'DELIVERY')
				{
					$unit_price = $InvoiceDetails[$i]->unitPrice;
					$item = array(
						"SKU" => "$conns_sku",
						"Model" => "$conns_sku",
						"Description" =>"STANDARD DELIVERY CHARGE",
						"PriceEach" => "$unit_price",
						"Quantity" => "$quantity"
					);
				}
				if($InvoiceDetails[$i]->connsSku == 'INSTALLATION')
				{
					$unit_price = $InvoiceDetails[$i]->unitPrice;
					$item = array(
						"SKU" => "$conns_sku",
						"Model" => "$conns_sku",
						"Description" =>"INSTALL",
						"PriceEach" => "$unit_price",
						"Quantity" => "$quantity"
					);
				}
				$merchandiseItems_arr[] = $item;
			}
		}else{
			return '';
		}
	  
		return $merchandiseItems_arr;
	  
	}
	
	public function _makeSubmitInvoiceApiCall(){
	
		$enablelog			=	$this->scopeConfig->getValue('payment/progressive/enable_logs');
		$writer 			= 	new \Zend\Log\Writer\Stream(BP . '/var/log/support_report_progressive.log');
		$logger 			= 	new \Zend\Log\Logger();
		$logger->addWriter($writer);
		$returnArr			=	array();
		$errorResponse  	= 	false;
		$response 			= 	$this->customerSession->getConnsQuoteResponse();
		$customerID			= 	$response->Billing->connsCustomerId;
		$subTotal			= 	$response->InvoiceFooter->subTotal;
		$taxAmount			= 	$response->InvoiceFooter->taxAmount;
		$leaseNumber		=	$this->checkoutSession->getYesleaseApprovedNumber();
		$InvoiceDetails 	= 	$response->InvoiceDetails->InvoiceDetail;
		$invoiceTotal 		= 	$response->InvoiceFooter->grandTotal;
		$worksheetId 		= 	$response->connsQuoteNumber;
		if($enablelog==1){
            $logger->info("Submit Invoice API Call Started");
			$logger->info(print_r($InvoiceDetails, true));
        }
		$merchandiseItems_arr	=	$this->prepareRequestForsubmitInvoice($InvoiceDetails);
		$invoice_arr = array(
			"InvoiceNumber" => "$worksheetId",
			"InvoiceTotal" => "$invoiceTotal",
			"AdditionalAmountDown" => "0",
			"DeliveryCharge" => "0",
			"SalesTax" => "0",
			"InvoiceDate" => "2019-09-26T00:00:00",
			"DeliveryDate" => "2019-09-26T00:00:00",
			"MerchandiseItems" => $merchandiseItems_arr
						
		);
		
		$quoteObject = array(
			"StateCode" => "TX",
			"LeaseID" => "$leaseNumber",
			"Invoice" => $invoice_arr,
			"DeliverContract" => "false"
		);
		
		if($enablelog==1){
            $logger->info("Submit Invoice Request preparation");
			$logger->info(print_r($quoteObject, true));
        }
		$authResult =	$this->__maketokenapicall();
		if ($authResult) {
			$authResult = json_decode($authResult);
			if (isset($authResult->access_token)) {
				$resobj = $this->submitInvoiceApi($authResult->access_token, json_encode($quoteObject));
				if($enablelog==1){
					$logger->info("Submit Invoice API Response;");
					$logger->info(print_r($resobj, true));
				}
				if (!is_string($resobj) || $resobj == "") {
					$errorResponse = true;
				}

				$decodedRespobj = json_decode($resobj);
				if (is_string($resobj) && $resobj != "") {
					if (!is_object($decodedRespobj) && !is_array($decodedRespobj)) {
						$errorResponse = true;
					}

					if (is_array($decodedRespobj)) {
						if (trim($decodedRespobj['code']) != "200" || trim($decodedRespobj['data']) == "" || trim($decodedRespobj['data']) == null) {
							$errorResponse = true;
						}
						
					}

				}


				if ($errorResponse) {
					if (!empty($decodedRespobj->message)) {
						$returnArr['status']	=	"error";
						$returnArr['error']		= __($decodedRespobj->message);
					}else{
						$returnArr['status']	=	"error";
						$returnArr['msg']		=	"There is some error in processing your request. Please try again.";
					}
					
				}else{
					$resobj = json_decode($resobj);
					if ($resobj->code == '200') {
						$resp = $resobj->data;
						if($resp){
							$eSignUrl	=	isset($resp->EsignURL)? $resp->EsignURL : '';
							if($eSignUrl && ($resobj->message == 'success')){
								$this->checkoutSession->setYesleaseEsignUrl($eSignUrl);
								$returnArr['status']	=	"success";
								$returnArr['esignurl']	=	$eSignUrl;
								if($enablelog==1){
									$logger->info("Submit Invoice API response in 200;");
									$logger->info(print_r($returnArr, true));
								}
								
							}
						}
					}else{
						$returnArr['status']	=	"error";
						$returnArr['msg']		=	"There is some error in processing your request. Please try again.";
					}
				}
				
			}
		}else{
			$returnArr['status']	=	"error";
			$returnArr['msg']		=	"There is some error in processing your request. Please try again.";
		}
		return json_encode($returnArr);
	
	}
	

      public function sendYesleaseOrderEmail()
    {
		$lastorderId = $this->checkoutSession->getLastOrderId();
		$objectManager =  \Magento\Framework\App\ObjectManager::getInstance();
		$order = $objectManager->create('\Magento\Sales\Model\Order')->load($lastorderId);
        //echo 'Paymet--'.$order->getPayment()->getMethod();exit;
		if($order->getPayment()->getMethod() != 'progressive') {
            return;
        }
       // echo 'My Order Id'.$lastorderId;
		$email = $order->getCustomerEmail();
        
        
        $templateOptions = array('area' => \Magento\Framework\App\Area::AREA_FRONTEND,'store' => 1); 

        $templateVars = array(
            'store' => 1,
            'orderNumber' => $order->getIncrementId(),
            'customer_name' => $order->getCustomerName(),
            'items'=> $order->getAllItems(),
        );
		 $email1 = $this->storeConfig->getValue('trans_email/ident_support/email',ScopeInterface::SCOPE_STORE);

        $from = array(
            'email' => 'email1',
            'name' => 'Conns'
        );

        //$to = "hina.thakur@conns.com";//please write your email address
		//$to = $email;
		$to = array($email);
		//for()
        try {
			for($i=0;$i<count($to);$i++){
            $this->_inlineTranslation->suspend();
            $to = array($to[$i]);
            $transport = $this->_transportBuilder->setTemplateIdentifier('yes_lease_sales_order_place')
                ->setTemplateOptions($templateOptions)
                ->setTemplateVars($templateVars)
                ->setFrom($from)
                ->addTo($to[$i])
                ->getTransport();
            $transport->sendMessage();
            $this->_inlineTranslation->resume();
			}
        }
        catch (\Exception $e)
        {
            echo $e->getMessage();
        }
    
		//exit("Stop123");
    }
}