<?php
namespace Conns\Yeslease\Model\Email\Sender;
use Magento\Sales\Model\Order;
class OrderSender extends \Magento\Sales\Model\Order\Email\Sender\OrderSender
{
    protected function prepareTemplate(Order $order)
    {
        parent::prepareTemplate($order);
        $paymentMethod = $order->getPayment()->getMethod();
        switch ($paymentMethod) {
            case 'progressive' : $templateId = '42'; break;
            default:
                $templateId = $order->getCustomerIsGuest() ?
                $this->identityContainer->getGuestTemplateId()
                : $this->identityContainer->getTemplateId();

        }

        $this->templateContainer->setTemplateId($templateId);
    }

}