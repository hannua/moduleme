<?php
namespace Conns\Yeslease\Model\Payment;
use Magento\Directory\Helper\Data as DirectoryHelper;
use Conns\Sales\Model\Sales\Order;
use mysql_xdevapi\Exception;

class Progressive extends \Magento\Payment\Model\Method\AbstractMethod
{

    /**
     * Payment code
     *
     * @var string
     */
    const PAYMENT_METHOD_PROGRESSIVE_CODE = 'progressive';
	
	protected $_code = self::PAYMENT_METHOD_PROGRESSIVE_CODE;
	
	/**
     * @var bool
     */
    protected $_isOffline = true;
    /**
     * @var bool
     */
    protected $_isGateway = true;
    /**
     * @var bool
     */
    protected $_canAuthorize = true;
    /**
     * @var bool
     */
    protected $_canUseCheckout = true;
    /**
     * @var bool
     */
    protected $_isInitializeNeeded = true;
    /**
     * @var
     */
    
    protected $checkoutSession;
    
    /**
     * @var \Conns\CreditApplication\Helper\Url
     */
    protected $_urlHelper;

    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $_checkoutSession;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;

    /**
     * @var Credit
     */
    protected $_credit;

    /**
     * @var \Magento\Customer\Model\Customer
     */
    protected $_customer;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    protected $_dateTime;

    /**
     * @var Order
     */
    protected $_order;

    /**
     * Credit constructor.
     * @param Order $order
     * @param \Magento\Framework\App\RequestInterface $requestHttp
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $dateTime
     * @param \Magento\Customer\Model\Customer $customer
     * @param \Conns\Credit\Model\Credit $credit
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Conns\CreditApplication\Helper\Url $urlHelper
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory
     * @param \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory
     * @param \Magento\Payment\Helper\Data $paymentData
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Payment\Model\Method\Logger $logger
     * @param \Magento\Framework\Model\ResourceModel\AbstractResource|null $resource
     * @param \Magento\Framework\Data\Collection\AbstractDb|null $resourceCollection
     * @param array $data
     * @param DirectoryHelper|null $directory
     */
    public function __construct(
        Order $order,
        \Magento\Framework\Stdlib\DateTime\DateTime $dateTime,
        \Magento\Customer\Model\Customer $customer,
		\Magento\Customer\Model\Session $customerSession,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory,
        \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory,
        \Magento\Payment\Helper\Data $paymentData,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Payment\Model\Method\Logger $logger,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = [],
        DirectoryHelper $directory = null)
    {
        $this->_order           = $order;
		$this->_dateTime        = $dateTime;
        $this->_customer        = $customer;
        $this->_customerSession = $customerSession;
        $this->_checkoutSession = $checkoutSession;
        
        parent::__construct($context, $registry, $extensionFactory, $customAttributeFactory, $paymentData, $scopeConfig, $logger, $resource, $resourceCollection, $data, $directory);
    }

    /**
     * @return string|null
     */
    public function getOrderPlaceRedirectUrl()
    {
        return $this->getRedirectUrl();
    }

    /**
     * @return string
     */
    public function getCheckoutMethod(){
        return $this->_checkoutSession->getQuote()->getCheckoutMethod();
    }

    /**
     * @return bool
     */
    public function isLoggedIn(){
        return $this->_customerSession->isLoggedIn();
    }
	
	
	
	
	/**
     * @param string $paymentAction
     * @param object $stateObject
     * @return $this|\Magento\Payment\Model\Method\AbstractMethod
     * @throws \Exception
     */
    public function initialize($paymentAction, $stateObject)
    {
        
        $myQuote     = $this->_checkoutSession->getQuote();
        $orderNumber = $myQuote->getReservedOrderId();
        
        $Totals            = $myQuote->getTotals();
        $now               = $this->_dateTime->timestamp(time());
        $timeNow           = date('Y-m-d.H.i.s', $now);
        $currentCustomerID = $this->_customerSession->getCustomer()->getId();
        if (!$currentCustomerID) {
            $currentCustomerID = $myQuote->getCustomerId();
        }
        
        if ($currentCustomerID) {
            $credit->loadByMagentoUserId($currentCustomerID);
        }
       
        $this->_checkoutSession->setYesleaseOrderId($orderNumber);
        
        $stateObject->setState("approvedyesmoney");
        $stateObject->setStatus('docusign_complete');
        $stateObject->setIsNotified(false);
        return $this;
    }

    /**
     * @return bool
     */
    public function hasVerification()
    {
        return false;
    }
}