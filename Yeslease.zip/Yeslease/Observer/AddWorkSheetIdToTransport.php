<?php

namespace Conns\Yeslease\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class AddWorkSheetIdToTransport implements ObserverInterface
{
    public function execute(Observer $observer)
    {
        $transport = $observer->getEvent()->getTransport();
        $order = $transport->getOrder();
        $paymentMethod = $order->getPayment()->getMethod();
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $checkoutSession = $objectManager->create(\Magento\Checkout\Model\Session::class);
              
        if($paymentMethod == 'progressive'){            
            $worksheetId = $checkoutSession->getYesleaseQuoteNumber();
            $transport['worksheetid'] = $worksheetId;            
        }
    }

}