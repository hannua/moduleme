<?php 
namespace Conns\Yeslease\Observer;
 
use Magento\Framework\DataObject;
use Magento\Framework\Encryption\EncryptorInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Exception\LocalizedException;
use Magento\Payment\Observer\AbstractDataAssignObserver;
use Magento\Quote\Api\Data\PaymentInterface;
use Magento\Payment\Model\InfoInterface;
 
class DataAssignObserver extends AbstractDataAssignObserver
{
    /**
     * @param Observer $observer
     * @throws LocalizedException
     */
	 
	protected $dataHelper;
	
	public function __construct(
		
		\Conns\Yeslease\Helper\Data $dataHelper
		
	) {
      
	  $this->dataHelper = $dataHelper;
	  
	}
	 
    public function execute(Observer $observer)
    {	
		$writer 			= 	new \Zend\Log\Writer\Stream(BP . '/var/log/support_report_progressive.log');
		$logger 			= 	new \Zend\Log\Logger();
		$logger->addWriter($writer);
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $checkoutSession = $objectManager->create(\Magento\Checkout\Model\Session::class);
        $paymentType = $checkoutSession->getYesleasePaymentType();  
		$logger->info('payment type :' . $paymentType);
        if(isset($paymentType) && $paymentType == "progressive"){
			$resp	=	$this->dataHelper->_makeSubmitInvoiceApiCall();
			$response	=	json_decode($resp);
			if(($response->status=='success') && ($response->esignurl)){
				$logger->info("payment type api resp");
				$logger->info(print_r(json_decode($resp), true));
				$payment = $observer->getPaymentModel();
				if (!$payment instanceof InfoInterface) {
					$payment = $paymentMethod->getInfoInstance();
				}
		 
				if (!$payment instanceof InfoInterface) {
					throw new LocalizedException(__('Payment model does not provided.'));
				}
				$leaseNumber 		= 	$checkoutSession->getYesleaseApprovedNumber();
				$approvedAmount 	= 	$checkoutSession->getYesleaseApprovedAmount();
				$transaction_id 	= 	$checkoutSession->getYesleaseTransactionID();
				$esignUrl		 	= 	$checkoutSession->getYesleaseEsignUrl();
				if($esignUrl){
					$esignUrl	=	$response->esignurl;
					$checkoutSession->setYesleaseEsignUrl($esignUrl);
				}
				$logger->info('payment type leaseNumber :' . $leaseNumber);
				$logger->info('payment type ApprovedAmount:' . $approvedAmount);
				$data = [];
				if(isset($approvedAmount)){
					$data['approved_amount'] = $approvedAmount;
				}
				if(isset($transaction_id)){
					$data['transaction_id'] = $transaction_id;
				}
				if(isset($leaseNumber)){
					$data['lease_number'] = $leaseNumber;
				}
				if(isset($esignUrl)){
					$data['esign_url'] = $esignUrl;
				}
				if(!empty($data)){
					$payment->setAdditionalInformation($data);
				}
				return true;
			}else{
				throw new LocalizedException(__('We experienced an issue while processing your order. Please try to submit your order again.'));
				
				return false;
			}
        }
    }
}