<?php
 
namespace Conns\Yeslease\Observer;
 
use Magento\Framework\Event\ObserverInterface;
 
class SendYesleaseEmail implements ObserverInterface
{   
 
    /**
     * @var \Magento\Sales\Model\Order\Email\Sender\OrderSender
     */
    protected $orderSender;
 
    /**
     * @var \Magento\Checkout\Model\Session $checkoutSession
     */
    protected $checkoutSession;
 
    /**
     * @param \Magento\Sales\Model\OrderFactory $orderModel
     * @param \Magento\Sales\Model\Order\Email\Sender\OrderSender $orderSender
     * @param \Magento\Checkout\Model\Session $checkoutSession
     *
     * @codeCoverageIgnore
     */
    public function __construct(        
        \Magento\Sales\Model\Order\Email\Sender\OrderSender $orderSender,
        \Magento\Checkout\Model\Session $checkoutSession
    )
    {        
        $this->orderSender = $orderSender;
        $this->checkoutSession = $checkoutSession;
    }
 
    /**
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {        
        $order = $observer->getEvent()->getOrder();        
        $paymentMethod = $order->getPayment()->getMethod();
        if($paymentMethod == 'progressive'){
            $this->checkoutSession->setForceOrderMailSentOnSuccess(true);            
            $this->orderSender->send($order, true);                
        }            
        
    }
}