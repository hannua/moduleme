/**
 * Copyright Â© Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

/* @api */
define([
    'jquery',
    'ko',
    'Magento_Checkout/js/view/payment/default',
    'Magento_Checkout/js/model/quote',
    'mage/url',
	'Magento_Checkout/js/action/get-totals',
	'Magento_Customer/js/customer-data',
	'Magento_Checkout/js/model/totals',
	'mage/validation',
	"mage/calendar"
], function ($,ko,Component,quote,url,getTotalsAction,customerData,totals) {
    'use strict';
	
	

    return Component.extend({

        defaults: {
            template: 'Conns_Yeslease/payment/progressive',
			image : window.checkoutConfig.payment.progressive.image,
			autoLeaseNumberForCheckout : window.checkoutConfig.payment.progressive.autoLeaseNumberForCheckout,
            openEyeImage : window.checkoutConfig.payment.progressive.openEyeImage,
            closeEyeImage : window.checkoutConfig.payment.progressive.closeEyeImage,
        },
		
		validateForm: function (form) {
                 return $(form).validation() && $(form).validation('isValid');
        },
		
		
			
        verify : function () {
            var self = this;
			var leasenumber		=	$("#applicant_lease_number").val();
			var last4ssn		=	$("#applicant_lastfour_ssn").val();
			var applicant_dob	=	$("#applicant_dob").val();
			var apiUrl			=	'';
			var currentApiName	=	$('#yl-click-here').val();
			$("#yesleaseverified").val(0);
			if((currentApiName!='verifylease') && (applicant_dob) && (applicant_dob != '') && (applicant_dob != 'undefined')){
				apiUrl	=	'/yeslease/checkout/searchlease';
			
			}else 
			{
				apiUrl	=	'/yeslease/checkout/verifylease';
				
			}
			
			if((currentApiName!='verifylease' || currentApiName=='') && (!last4ssn || (last4ssn =='')) && ((!applicant_dob) || (applicant_dob == ''))){
				$('.onepage-yeslease-msg .yeslease-err-msg').html("Please select a valid date of birth and provide the last 4 digits of your SSN.");
				$('.yeslease-succ-msg').hide();
				$('.yeslease-err-msg').show();
				$("#applicant_dob").addClass('error-border');
				$("#applicant_lastfour_ssn").addClass('error-border');
				$("#applicant_lease_number").removeClass('error-border');
				$("#conns-progressive-continue").prop("disabled", true);
				return;
			}
			
			if((!last4ssn) || (last4ssn == '')){
				$('.onepage-yeslease-msg .yeslease-err-msg').html("Please enter the information requested.");
				$('.yeslease-succ-msg').hide();
				$('.yeslease-err-msg').show();
				if(applicant_dob && (applicant_dob != '') && (applicant_dob != 'undefined')){
					$("#applicant_dob").addClass('error-border');
					$("#applicant_lastfour_ssn").addClass('error-border');
					$("#applicant_lease_number").removeClass('error-border');
				}else{
					$("#applicant_lease_number").addClass('error-border');
					$("#applicant_lastfour_ssn").addClass('error-border');
					$("#applicant_dob").removeClass('error-border');
				}
				$("#conns-progressive-continue").prop("disabled", true);
				return;
			}
			
			
			if (!this.validateForm('#conns-progressive-form')) {
			   return;
			}
			
			$.ajax({
				url : apiUrl,
				method: "POST",
				showLoader: true,
				data : $('#conns-progressive-form').serialize(),
				success: function(result, textStatus, jqXHR) {
					console.log(result);
					var results = JSON.parse(result);
					showLoader: false;
					
					if(results.status == 'success'){
						$('.onepage-yeslease-msg .yeslease-succ-msg').html(results.msg);
						$('.yeslease-succ-msg').show();
						$('.yeslease-err-msg').hide();
						$("#applicant_dob").removeClass('error-border');
						$("#applicant_lastfour_ssn").removeClass('error-border');
						$("#applicant_lease_number").removeClass('error-border');					
						$("#conns-progressive-continue").prop("disabled", false);
						$("#yesleaseverified").val(1);
						
					}else{
						$('.onepage-yeslease-msg .yeslease-err-msg').html(results.msg);
						$('.yeslease-succ-msg').hide();
						$('.yeslease-err-msg').show();
						if(applicant_dob && (applicant_dob != '') && (applicant_dob != 'undefined')){
							$("#applicant_dob").addClass('error-border');
							$("#applicant_lastfour_ssn").addClass('error-border');
							$("#applicant_lease_number").removeClass('error-border');
						}else{
							$("#applicant_lease_number").addClass('error-border');
							$("#applicant_lastfour_ssn").addClass('error-border');
							$("#applicant_dob").removeClass('error-border');
						}
						$("#conns-progressive-continue").prop("disabled", true);
					}
					
					
				},
				error: function (jqXHR, textStatus, errorThrown) {
					showLoader: false;
					$('.onepage-yeslease-msg .yeslease-err-msg').html("There is some error in processing your request. Please try again.");
					if(applicant_dob && (applicant_dob != '') && (applicant_dob != 'undefined')){
						$("#applicant_dob").addClass('error-border');
						$("#applicant_lastfour_ssn").addClass('error-border');
						$("#applicant_lease_number").removeClass('error-border');
					}else{
						$("#applicant_lease_number").addClass('error-border');
						$("#applicant_lastfour_ssn").addClass('error-border');
						$("#applicant_dob").removeClass('error-border');
					}
					$('.yeslease-succ-msg').hide();
					$('.yeslease-err-msg').show();
					console.log(jqXHR);
					console.log(textStatus);
					console.log(errorThrown);
				}
            });
            
        },
		eyeclick : function () {
            $("#applicant_lastfour_ssn").attr("type") == "password" ?
                $("#applicant_lastfour_ssn").attr("type","text") :
                $("#applicant_lastfour_ssn").attr("type","password");
            $("#applicant_lastfour_ssn").attr("type") == "password" ?
                $("#yeslease-eye-icon").attr("src",this.closeEyeImage) :
                $("#yeslease-eye-icon").attr("src",this.openEyeImage);
        },
		isNumber : function (data,event) {
            var iKeyCode = (event.which) ? event.which : event.keyCode;
            if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57)) {
                return false;
            }
            return true;
        },
		isCalender : function (data,event) {
            var iKeyCode = (event.which) ? event.which : event.keyCode;
            if (iKeyCode) {
				$("#applicant_dob").focus();
                return false;
            }
            return true;
        },
		fieldInit : function () {
            $("#conns-progressive-continue").prop("disabled", true);
			$('#applicant_dob').val('');
        },
		
		showcalender: function () {
			$("#applicant_dob").focus();
           
        },
		
		
		clickhere : function () {
			var maxBirthDate = new Date();
			maxBirthDate = new Date(maxBirthDate.setYear(maxBirthDate.getFullYear() - 19));
			var maxYear = maxBirthDate.getFullYear();
			var min = new Date("Jan 01, 1901");
			var max = new Date("Dec 31, "+maxYear);
			$("#applicant_dob").calendar({
				changeMonth: true,
				changeYear: true,
				minDate: min,
				maxDate: max,
				showButtonPanel: true,
				singleClick : true,
				hideIfNoPrevNext: true,
				yearRange: "1901:"+maxYear,
                buttonText: "Select Date"
			});
			$('<style type="text/css"> .ui-datepicker-close { display: none; } </style>').appendTo("head");
			$('<style type="text/css"> .ui-datepicker-current  { display: none; } </style>').appendTo("head");
			$('.yeslease-succ-msg').hide();
			$('.yeslease-succ-msg').hide();
			$('.yeslease-err-msg').hide();
			var currentApiName	=	$('#yl-click-here').val();
			if((currentApiName=='verifylease') || (currentApiName == '')){
			
				$('.onepage-leaseid').css('display','none');
				$('#applicant_lease_number').val('');
				$('.onepage-lease-dob').css('display','block');
				$('#yl-click-here').attr('value','searchlease');
				$("#applicant_lastfour_ssn").removeClass('error-border');
				$('#forgetleaseid-content').html('Have approved Lease ID');
			}else{
				$('#applicant_dob').val('');
				$('.onepage-leaseid').css('display','block');
				$('.onepage-lease-dob').css('display','none');
				$('#yl-click-here').attr('value','verifylease');
				$("#applicant_lastfour_ssn").removeClass('error-border');
				$('#forgetleaseid-content').html('Forgot Lease ID');
			}
        },
		progressiveApproved : function () {
            var self = this;
            var selection = $("#p_method_progressive").val();
			var isYLVerified = $("#yesleaseverified").val();
			if(isYLVerified==1 && selection=="progressive"){
				$.ajax({
					url : '/yeslease/checkout/invoicequote',
					method: "POST",
					showLoader: true,
					data : {
						'paymentType': selection,
					},
					success: function(result, textStatus, jqXHR) {
						console.log(result);
						var results = JSON.parse(result);
						showLoader: false;

						if(results.message == 'success'){
							var paymentOption = $('#p_method_progressive').parents("div.payment-method._active");
							$(paymentOption).removeClass('selected-payment');
							$('.opc-order-review-block__content').show();
							$('html,body').animate({
									scrollTop: $(".opc-order-review-block").offset().top},
								'slow');
							
							/* Totals summary reloading */  
							var deferred = $.Deferred();
							getTotalsAction([], deferred);

                            // $(".payment-method").hide();
                            // paymentOption.show();
                            $(".opc-order-review-block__summary").children(".table-totals").find('tbody>tr.grand').before("<tr class=\"totals-tax\">\n" +
                                "    <th class=\"mark\" colspan=\"1\" scope=\"row\">Tax(Sales Tax will be collected by Progressive leasing as part of your monthly\n" +
                                "payment)</th>\n" +
                                "    <td class=\"amount\" data-th=\"Tax\">\n" +
                                "        <span class=\"price\">$0.00</span>\n" +
                                "    </td>\n" +
                                "</tr>")
						}else{
							$('.onepage-yeslease-msg .yeslease-err-msg').html(results.message);
							$('.yeslease-succ-msg').hide();
							$('.yeslease-err-msg').show();
						}


					},
					error: function (jqXHR, textStatus, errorThrown) {
						showLoader: false;
						$('.onepage-yeslease-msg .yeslease-err-msg').html("There is some error in processing your request. Please try again.");
						if(applicant_dob && (applicant_dob != '') && (applicant_dob != 'undefined')){
							$("#applicant_dob").addClass('error-border');
							$("#applicant_lastfour_ssn").addClass('error-border');
							$("#applicant_lease_number").removeClass('error-border');
						}else{
							$("#applicant_lease_number").addClass('error-border');
							$("#applicant_lastfour_ssn").addClass('error-border');
							$("#applicant_dob").removeClass('error-border');
						}
						$('.yeslease-succ-msg').hide();
						$('.yeslease-err-msg').show();
						console.log(jqXHR);
						console.log(textStatus);
						console.log(errorThrown);
					}
				});
			}else{
				$('.onepage-yeslease-msg .yeslease-err-msg').html("There is some error in processing your request. Please try again.");
				$('.yeslease-succ-msg').hide();
				$('.yeslease-err-msg').show();
				var applicant_dob	=	$("#applicant_dob").val();
				if(applicant_dob && (applicant_dob != '') && (applicant_dob != 'undefined')){
					$("#applicant_dob").addClass('error-border');
					$("#applicant_lastfour_ssn").addClass('error-border');
					$("#applicant_lease_number").removeClass('error-border');
				}else{
					$("#applicant_lease_number").addClass('error-border');
					$("#applicant_lastfour_ssn").addClass('error-border');
					$("#applicant_dob").removeClass('error-border');
				}
			}
        }
    });
});